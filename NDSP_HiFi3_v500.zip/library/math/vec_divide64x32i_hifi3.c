/* ------------------------------------------------------------------------ */
/* Copyright (c) 2021-2025 Cadence Design Systems, Inc. ALL RIGHTS RESERVED.*/
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence license.                                      */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library for HiFi 3 and 3z DSP                                  */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (c) 2009-2021 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */
/*
  NatureDSP Signal Processing Library. Math functions
    Division
    C code optimized for HiFi3
  IntegrIT, 2006-2018
*/

#include "NatureDSP_Signal_math.h"
#include "common.h"

#if defined AE_MOVAB && defined AE_MOVAB2 && defined AE_MOVBA
#define _HIFI3Z_OPT_ 1
#else
#define _HIFI3Z_OPT_ 0
#endif

/*-------------------------------------------------------------------------
  Division
  These routines perform pair-wise division of vectors written in Q31 or Q15 
  format. They return the fractional and exponential portion of the division 
  result. Since the division may generate result greater than 1, it returns 
  fractional portion frac in Q(31-exp) or Q(15-exp) format and exponent 
  exp so true division result in the Q0.31 may be found by shifting 
  fractional part left by exponent value.
  Additional routine makes integer division of 64-bit number to 32-bit 
  denominator forming 32-bit result. If result is overflown, 0x7fffffff 
  or 0x80000000 is returned depending on the signs of inputs.
  For division to 0, the result is not defined.

  Two versions of routines are available: regular versions (vec_divide64x32i,
  vec_divide32x32, vec_divide24x24, vec_divide16x16) work with arbitrary
  arguments, faster versions (vec_divide32x32_fast, vec_divide24x24_fast, 
  vec_divide16x16_fast) apply some restrictions.

  Accuracy is measured as accuracy of fractional part (mantissa):
  vec_divide64x32i, scl_divide64x32                      :  1 LSB   
  vec_divide32x32, vec_divide32x32_fast                  :  2 LSB (1.8e-9) 
  scl_divide32x32, vec_divide24x24, scl_divide24x24      :  2 LSB (4.8e-7) 
  vec_divide16x16, scl_divide16x16, vec_divide16x16_fast :  2 LSB (1.2e-4)

  Precision: 
  64x32i integer division, 64-bit nominator, 32-bit denominator, 32-bit output. 
  32x32  fractional division, 32-bit inputs, 32-bit output. 
  24x24  fractional division, 24-bit inputs, 24-bit output. 
  16x16  fractional division, 16-bit inputs, 16-bit output. 

  Input:
  x[N]    nominator, 64-bit integer, Q31 or Q15
  y[N]    denominator, 32-bit integer, Q31 or Q15
  N       length of vectors
  Output:
  frac[N] fractional parts of result, Q(31-exp) or Q(15-exp)
  exp[N]  exponents of result 

  Restriction:
  For regular versions (vec_divide64x32i, vec_divide32x32,
  vec_divide24x24, vec_divide16x16) :
  x,y,frac,exp should not overlap

  For faster versions (vec_divide32x32_fast, vec_divide24x24_fast, 
  vec_divide16x16_fast) :
  x,y,frac,exp  should not overlap
  x,y,frac      to be aligned by 8-byte boundary, N - multiple of 4.

  Scalar versions:
  ----------------
  scl_divide64x32(): integer remainder
  Return packed value: 
  scl_divide24x24(),scl_divide32x32():
  bits 23:0 fractional part
  bits 31:24 exponent
  scl_divide16x16():
  bits 15:0 fractional part
  bits 31:16 exponent
-------------------------------------------------------------------------*/
void vec_divide64x32i
                (int32_t * restrict frac, 
                 const int64_t * restrict x, 
                 const int32_t * restrict y, int N)
{
/*algorithm:
  f(x,y) = div(x,y) = x/y = x*recip(y)

1)  f(y) = recip(y) = 1/y
Rough calculation:
  f(y) = f(y0) + f'(y0)*(y1-y0)
  1/y0 = f(y0)
  1/(y0^2) = f'(y0)
  y1 = y*2^nsa, y1 in 0.5..1
  y1-y0 = dy
Refiniment:
  err = f(y)*y - 1 ,error of calculation
  recip(y) = f(y) - err*f(y), refined value
2)f(x,y) = x*recip(y)
  */
#if _HIFI3Z_OPT_
  int n;
  const ae_int64   * restrict px = (const ae_int64   *)x;
  const ae_int32x2 * restrict py = (const ae_int32x2 *)y;
        ae_int32x2 * restrict pz = (      ae_int32x2 *)frac;

  unsigned char sg0, sg1;
  xtbool2 b0, ovl;  
  xtbool  bl0, bl1;
  ae_int64 x0, x1, s1, s2;
  ae_int32x2 y0, z0, s0, z1;
  ae_int32x2 maxint = AE_MOVDA32X2( 0x7FFFFFFF,0x7FFFFFFF );
  ae_valign y_align, z_align;

  if(N<=0) return;
  z_align = AE_ZALIGN64();
  y_align = AE_LA64_PP(py);  
  
  s0 = AE_MOVDA32X2( 0x00000000,0xFFFFFFFF );
  s2 = AE_MOVINT64_FROMINT32X2(s0);//;AE_MOV64( 0x00000000FFFFFFFF);
  
  s0 = AE_ZERO32(); 
  s1 = AE_ZERO64(); 
  for (n=0;n<(N>>1);n++)
  {
    AE_L64_IP(x0, px, sizeof(ae_int64));
    AE_L64_IP(x1, px, sizeof(ae_int64));
    AE_LA32X2_IP(y0, y_align, py);

    b0 = AE_LT32(y0,s0);
    bl0 = AE_LT64(x0,s1);
    bl1 = AE_LT64(x1,s1);
    sg1 = AE_MOVAB2(b0);
    sg0 = (AE_MOVAB(bl0)<<1)|(AE_MOVAB(bl1));
    sg0 = sg0^sg1;
    x0 = AE_ABS64S(x0);
    x1 = AE_ABS64S(x1);
    y0 = AE_ABS32S(y0);

    z0 = AE_TRUNCA32X2F64S(x0,x1,0);
    ovl = AE_LE32(y0,z0);

    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
                   
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);
    AE_DIV64D32_L(x1,y0);

    /////////////////////////////

    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
                   
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);

    x0 = AE_AND64(x0,s2);
    x1 = AE_AND64(x1,s2);
    z0 = AE_TRUNCA32X2F64S(x0,x1,32);

    AE_MOVT32X2(z0,maxint,ovl);

    z1 = AE_NEG32S(z0);
    AE_MOVT32X2(z0,z1,sg0);
    AE_SA32X2_IP(z0,z_align,pz);
  } 
  AE_SA64POS_FP(z_align,pz);
  if (N&1)
  {
    AE_L64_IP(x0, px, sizeof(ae_int64));
    y0 = AE_L32_I((const ae_int32 *)py, 0);

    b0 = AE_LT32(y0,s0);
    bl0 = AE_LT64(x0,s1);

    sg1 = AE_MOVAB2(b0);
    sg0 = AE_MOVAB(bl0);
    sg0 = sg0^sg1;
    x0 = AE_ABS64S(x0);
    y0 = AE_ABS32S(y0);

    z0 = AE_TRUNCA32X2F64S(x0,x0,0);
    ovl = AE_LE32(y0,z0);

    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);

    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);

    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);

    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);

    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);

    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);

    x0 = AE_AND64(x0,s2);
    z0 = AE_TRUNCA32X2F64S(x0,x0,32);

    AE_MOVT32X2(z0,maxint,ovl);

    z1 = AE_NEG32S(z0);
    AE_MOVT32X2(z0,z1,sg0);
    AE_S32_L_I(z0,(ae_int32 *)pz, 0); 
  }
#else
  int n;
  const ae_int64 * restrict px  = (const ae_int64 *)x;
  const ae_int32 * restrict py  = (const ae_int32 *)y;
  const ae_int32x2 * restrict px1 = (const ae_int32x2 *)x;
  const ae_int32 * restrict py1 = (const ae_int32 *)y;
        ae_int32 * restrict pz = (      ae_int32 *)frac;

  xtbool2 b0, ovl;  
  ae_int64 x0, s2;
  ae_int32x2 tx, y0, z0, s0, z1;
  ae_int32x2 maxint = AE_MOVDA32X2( 0x7FFFFFFF,0x7FFFFFFF );
  
  s0 = AE_MOVDA32X2( 0x00000000,0xFFFFFFFF );
  s2 = AE_MOVINT64_FROMINT32X2(s0);//;AE_MOV64( 0x00000000FFFFFFFF);
  
  s0 = AE_ZERO32(); 
  for (n=0;n<N;n++)
  {
    AE_L64_IP(x0, px, sizeof(int64_t));
    AE_L32_IP(y0, py, sizeof(int32_t));

    x0 = AE_ABS64S(x0);
    y0 = AE_ABS32S(y0);

    z0 = AE_TRUNCA32X2F64S(x0,x0,0);
    ovl = AE_LE32(y0,z0);

    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);

    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);

    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);

    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);

    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);

    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);
    AE_DIV64D32_H(x0,y0);

    x0 = AE_AND64(x0,s2);
    z0 = AE_TRUNCA32X2F64S(x0,x0,32);

    AE_MOVT32X2(z0,maxint,ovl);

    AE_L32X2_IP(tx, px1, sizeof(int64_t));
    AE_L32_IP(y0, py1, sizeof(int32_t));

    tx = AE_XOR32(tx, y0);
    b0 = AE_LT32(tx,s0);

    z1 = AE_NEG32S(z0);
    AE_MOVT32X2(z0,z1,b0);
    AE_S32_L_IP(z0, pz, sizeof(int32_t)); 
  }
#endif
}
